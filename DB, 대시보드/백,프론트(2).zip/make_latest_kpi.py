﻿import csv, json, os

CSV_PATH = r"C:\Users\user\Downloads\CV(이송장치)\test_17_18_with_pred_LSTM.csv"
OUT_JSON = r"C:\Users\user\Downloads\CV(이송장치)\latest_by_device.json"

def sk_to_int(sk: str) -> int:
    try:
        md, t = str(sk).split("_")
        return int(md) * 1000000 + int(t)  # MMDDHHMMSS
    except:
        return -1

def cls_to_name(c: int) -> str:
    c = int(c)
    return ["Normal (0)", "Attention (1)", "Warning (2)", "Danger (3)"][c]

latest = {}  # device_id -> (sk_int, rowdict)

with open(CSV_PATH, "r", encoding="utf-8-sig", newline="") as f:
    r = csv.DictReader(f)
    for row in r:
        did = row.get("device_id")
        sk = row.get("sort_key")
        if not did or not sk:
            continue
        key = sk_to_int(sk)
        cur = latest.get(did)
        if (cur is None) or (key >= cur[0]):
            latest[did] = (key, row)

rows = []
for did, (key, row) in sorted(latest.items()):
    y_true = int(float(row["y_true"]))
    y_pred = float(row["y_pred"])
    y_pred_cls = int(float(row["y_pred_cls"]))

    rows.append({
        "device_id": did,
        "sort_key": row["sort_key"],
        "current": {"state": y_true, "state_name": cls_to_name(y_true)},
        "pred":    {"score": y_pred, "state": y_pred_cls, "state_name": cls_to_name(y_pred_cls)},
    })

payload = {"server_time": None, "devices": rows}

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)

print("✅ saved:", OUT_JSON)
print("devices:", len(rows))
