﻿import csv, json

LSTM_CSV = r"C:\Users\user\Downloads\CV(이송장치)\test_17_18_with_pred_LSTM.csv"
MMT_CSV  = r"C:\Users\user\Downloads\CV(이송장치)\final_17_18_with_overlay_and_pred.csv"
OUT_JSON = r"C:\Users\user\Downloads\CV(이송장치)\latest_merged.json"

def sk_to_int(sk: str) -> int:
    try:
        md, t = str(sk).split("_")
        return int(md) * 1000000 + int(t)
    except:
        return -1

def cls_to_name(c: int) -> str:
    c = int(c)
    return ["Normal (0)", "Attention (1)", "Warning (2)", "Danger (3)"][c]

def read_latest(csv_path):
    latest = {}  # device_id -> (sk_int, row)
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            did = (row.get("device_id") or "").lower().strip()
            sk  = row.get("sort_key")
            if not did or not sk:
                continue
            k = sk_to_int(sk)
            cur = latest.get(did)
            if (cur is None) or (k >= cur[0]):
                latest[did] = (k, row)
    return latest

lstm_latest = read_latest(LSTM_CSV)
mmt_latest  = read_latest(MMT_CSV)

devices = sorted(set(lstm_latest.keys()) | set(mmt_latest.keys()))
rows = []

for did in devices:
    lstm = lstm_latest.get(did)
    mmt  = mmt_latest.get(did)

    # sort_key는 더 최신 쪽 기준
    if lstm and mmt:
        sort_key = (lstm if lstm[0] >= mmt[0] else mmt)[1].get("sort_key")
    elif lstm:
        sort_key = lstm[1].get("sort_key")
    else:
        sort_key = mmt[1].get("sort_key")

    out = {"device_id": did, "sort_key": sort_key}

    # ✅ current = LSTM 예측을 "현재 판단"으로 사용
    if lstm:
        r = lstm[1]
        cur_score = float(r.get("y_pred", 0.0))
        cur_state = int(float(r.get("y_pred_cls", 0)))
        out["current"] = {"score": cur_score, "state": cur_state, "state_name": cls_to_name(cur_state)}
    else:
        out["current"] = None

    # ✅ pred = MMT 예측
    if mmt:
        r = mmt[1]
        pred_score = float(r.get("y_pred", 0.0))
        pred_state = int(float(r.get("y_pred_cls", 0)))
        out["pred"] = {"score": pred_score, "state": pred_state, "state_name": cls_to_name(pred_state)}
    else:
        out["pred"] = None

    rows.append(out)

payload = {"server_time": None, "devices": rows}

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)

print("✅ saved:", OUT_JSON)
print("devices:", len(rows))
