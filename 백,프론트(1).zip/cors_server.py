﻿from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

class CORSRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

if __name__ == "__main__":
    port = 8099
    httpd = ThreadingHTTPServer(("127.0.0.1", port), CORSRequestHandler)
    print(f"Serving with CORS at http://127.0.0.1:{port}")
    httpd.serve_forever()
