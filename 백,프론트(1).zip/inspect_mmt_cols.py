﻿import csv

MMT_CSV = r"C:\Users\user\Downloads\CV(이송장치)\final_17_18_with_overlay_and_pred.csv"

with open(MMT_CSV, "r", encoding="utf-8-sig", newline="") as f:
    r = csv.reader(f)
    header = next(r)

print("✅ columns count:", len(header))
print("✅ first 30 columns:")
for c in header[:30]:
    print("-", c)

# 예측 후보 컬럼 자동 탐색
cands = []
for c in header:
    cl = c.lower()
    if any(k in cl for k in ["y_pred", "pred", "score", "state", "risk"]):
        cands.append(c)

print("\n✅ candidate columns (pred/score/state/risk):")
for c in cands[:80]:
    print("-", c)
if len(cands) > 80:
    print(f"... and {len(cands)-80} more")
