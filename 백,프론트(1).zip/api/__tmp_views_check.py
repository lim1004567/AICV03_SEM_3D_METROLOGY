﻿import os
import json
from threading import Lock
import csv
from threading import Lock
import time
from threading import Lock
from pathlib import Path
from threading import Lock
from datetime import datetime
from threading import Lock

from django.http import JsonResponse, HttpResponseBadRequest
from threading import Lock
from django.conf import settings
from threading import Lock
from django.shortcuts import render
from threading import Lock


CSV_PATH = Path(settings.BASE_DIR) / "final_17_18_with_overlay_and_pred.csv"

_cache = {
    "mtime": None,
    "rows": None,
    "by_device": None,          # device_id -> sorted rows
    "devices_latest": None,     # device_id -> latest row
}

_stream = {
    "inited": False,
    "pos": {},          # device_id -> cursor index
    "hist": {},         # device_id -> list of last window points (dict)
    "events": [],       # list of recent stream events (most recent first)
    "last_cls": {},     # device_id -> previous cls (for event detect)
    "last_tick_at": None,
}


def _load_csv_cached():
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")

    mtime = CSV_PATH.stat().st_mtime
    if _cache["rows"] is not None and _cache["mtime"] == mtime:
        return

    rows = []
    by_device = {}

    # ✅ BOM 가능성 때문에 utf-8-sig
    with CSV_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            op = (r.get("overlay_path") or "").strip()
            if op:
                r["overlay_url"] = settings.STATIC_URL + os.path.basename(op)
            else:
                r["overlay_url"] = None

            rows.append(r)
            did = r.get("device_id")
            if did:
                by_device.setdefault(did, []).append(r)

    # sort_key 오름차순 정렬
    devices_latest = {}
    for did, arr in by_device.items():
lp = os.path.join(os.path.dirname(_RECV_PATH), "streamtick_keys.log")
                with open(lp, "a", encoding="utf-8") as f:
                    f.write(f"{did} sort_key={r.get('sort_key')}\n")
            except Exception:
                pass
            _stream["pos"][did] = pos + 1

        cur_cls = str(r.get("y_pred_cls"))
        prev_cls = _stream["last_cls"].get(did)

        # 이벤트(상태 변화)
        if prev_cls is not None and cur_cls != prev_cls:
            up = int(cur_cls) > int(prev_cls)
            if (not only_up) or up:
                _push_event({
                    "device_id": did,
                    "from_cls": prev_cls,
                    "to_cls": cur_cls,
                    "y_pred": r.get("y_pred"),
                    "overlay_url": r.get("overlay_url"),
                    "t": int(now),
                })
        _stream["last_cls"][did] = cur_cls

        pt = {
            "y_pred": float(r.get("y_pred") or 0.0),
            "cls": int(cur_cls) if cur_cls.isdigit() else -1,
            "overlay_url": r.get("overlay_url"),
        }
hist = _stream["hist"].setdefault(did, [])
        hist.append(pt)
        if len(hist) > window:
            del hist[:-window]

        current[did] = pt

    # events_window 적용(초 기준으로 오래된 이벤트 제거)
    cutoff = int(now) - events_window
    _stream["events"] = [e for e in _stream["events"] if e.get("t", 0) >= cutoff]

    # KPI 계산
    total = len(current)
    danger = sum(1 for v in current.values() if v["cls"] == 3)
    warn = sum(1 for v in current.values() if v["cls"] == 2)
    peak_minute = None
    if _stream["events"]:
        # 같은 분(minute) 이벤트 수 집계해서 최대값
        cnt = {}
        for e in _stream["events"]:
            m = e["t"] - (e["t"] % 60)
            cnt[m] = cnt.get(m, 0) + 1
        peak_minute = max(cnt.items(), key=lambda x: x[1])[0]

    # Top risk: 현재 y_pred 최대
    top_risk = None
    if current:
        did, v = max(current.items(), key=lambda kv: kv[1]["y_pred"])
        top_risk = {"device_id": did, "score": v["y_pred"], "state": v["cls"]}

    # Latest Alert: 현재 snapshot 중 danger 우선, 없으면 warn
    latest_alert = None
    cand = [(did, v) for did, v in current.items() if v["cls"] in (2, 3)]
    if cand:
        # danger 우선
        cand.sort(key=lambda kv: (kv[1]["cls"], kv[1]["y_pred"]), reverse=True)
        did, v = cand[0]
        latest_alert = {
            "device_id": did,
            "state": v["cls"],
            "score": v["y_pred"],
            "overlay_url": v["overlay_url"],
        }

    # devices summary
    types = {"oht": 0, "agv": 0}
    for did in current.keys():
        if did.startswith("oht"):
            types["oht"] += 1
        elif did.startswith("agv"):
            types["agv"] += 1

    return JsonResponse({
        "ok": True,
        "server_time": _now_iso(),
        "active_devices": total,
        "device_types": types,
        "danger_now": danger,
        "warning_now": warn,
        "recent_events": len(_stream["events"]),
        "peak_minute": peak_minute,   # epoch minute start (UI에선 숨길 수도)
        "top_risk": top_risk,
        "latest_alert": latest_alert,
        "only_up": only_up,
        "events_window": events_window,
        "window": window,
        "current": current,           # device_id -> {y_pred, cls, overlay_url}
        "history": _stream["hist"],   # device_id -> list[{y_pred,cls,overlay_url}]
        "events": _stream["events"][:10],
    })


# ---------------------------
# ✅ SIGNALS APIs (for Signals tab)
# ---------------------------

def _get_fieldnames():
    _load_csv_cached()
    # 캐시된 rows가 있으면 첫 row의 keys로도 가능하지만, DictReader fieldnames가 더 안정적.
    # 여기서는 by_device의 첫 row keys로 대체
    by_device = _cache.get("by_device") or {}
    for _, arr in by_device.items():
        if arr:
            return list(arr[0].keys())
    return []

def _default_presets(fieldnames):
    # CSV에 있는 것만
    dust = [x for x in ["s29_PM10","s29_PM2_5","s29_PM1_0"] if x in fieldnames]
    thermal = [x for x in ["s29_CT1","s29_CT2","s29_CT3","s29_CT4","s29_NTC"] if x in fieldnames]
    internal = [x for x in [
        "s29_NTC","s29_PM10","s29_PM2_5","s29_PM1_0",
        "s29_CT1","s29_CT2","s29_CT3","s29_CT4"
    ] if x in fieldnames]
    # 외부환경은 현재 CSV에 없으므로 empty
    external = []
    return {
        "Dust": dust,
        "Thermal": thermal,
        "Internal": internal,
        "External": external,
    }

def signals_available(request):
    """
    신호 목록 + 프리셋 제공
    """
    fieldnames = _get_fieldnames()
    # s00~s29 블록 전체를 signals로 제공(너무 많으면 프론트에서 검색/필터)
    signals = [c for c in fieldnames if c.startswith("s") and "_" in c and c not in ("sort_key","overlay_url","overlay_path","bin_path")]
    presets = _default_presets(fieldnames)

    return JsonResponse({
        "device_hint": request.GET.get("device_id"),
        "presets": presets,
        "signals": signals,
        "external_mock": ["ex_temperature","ex_humidity","ex_illuminance"],
    })


def _stream_end_index(device_id: str):
    # stream cursor 기준으로 "현재까지 재생된 마지막 index"
    if not _stream.get("inited"):
        _stream_init(window=30)
    pos = _stream.get("pos", {}).get(device_id, 0)
    # tick에서 pos를 증가시키므로 end는 pos-1
    end = max(0, pos - 1)
    return end

def _slice_rows_by_cursor(device_id: str, limit: int):
    _load_csv_cached()
    arr = (_cache.get("by_device") or {}).get(device_id, [])
    if not arr:
        return []
    end = _stream_end_index(device_id)
    # end 포함해서 뒤로 limit개
    start = max(0, end - (limit - 1))
    return arr[start:end+1]

def signals_series(request):
    """
    /api/signals/series?device_id=agv17&signals=s29_CT2,s29_NTC&limit=60
    cursor 기반으로 최근 limit 포인트를 반환
    """
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    sigs = (request.GET.get("signals") or "").strip()
    if not sigs:
        return HttpResponseBadRequest("signals required (comma-separated)")
    signals = [s.strip() for s in sigs.split(",") if s.strip()]

    try:
        limit = int(request.GET.get("limit", "60"))
    except ValueError:
        limit = 60
    limit = max(3, min(limit, 20000))

    rows = _slice_rows_by_cursor(device_id, limit=limit)

    def fnum(x):
        try:
            return float(x)
        except Exception:
            return None

    points = []
    for r in rows:
        p = {
            "t": r.get("sort_key"),  # 프론트에서는 숨겨도 됨(축/커서용 내부키)
            "state": fnum(r.get("y_pred_cls")),
            "score": fnum(r.get("y_pred")),
        }
        for s in signals:
            if s.startswith("ex_"):
                p[s] = None
            else:
                p[s] = fnum(r.get(s))
                # attach real server-time when this point is served
        if "received_at" not in p:
            p["received_at"] = recv_get(device_id, p.get("t")) or _now_iso()
        points.append(p)

    return JsonResponse({
        "device_id": device_id,
        "signals": signals,
        "points": points,
        "limit": limit,
    })


def signals_inspect(request):
    """
    /api/signals/inspect?device_id=agv17&offset=0&signals=s29_CT2,s29_NTC
    offset=0: 현재 커서 포인트, offset=1: 직전 포인트 ...
    """
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    sigs = (request.GET.get("signals") or "").strip()
    signals = [s.strip() for s in sigs.split(",") if s.strip()] if sigs else []

    try:
        offset = int(request.GET.get("offset", "0"))
    except ValueError:
        offset = 0
    offset = max(0, min(offset, 600))

    _load_csv_cached()
    arr = (_cache.get("by_device") or {}).get(device_id, [])
    if not arr:
        return JsonResponse({"device_id": device_id, "point": None})

    end = _stream_end_index(device_id)
    idx = max(0, end - offset)
    r = arr[idx]

    def fnum(x):
        try:
            return float(x)
        except Exception:
            return None

    point = {
        "t": r.get("sort_key"),
        "state": fnum(r.get("y_pred_cls")),
        "score": fnum(r.get("y_pred")),
        "overlay_url": r.get("overlay_url"),
        "internal": {},
        "external": {"ex_temperature": None, "ex_humidity": None, "ex_illuminance": None},
    }

    for s in signals:
        if s.startswith("ex_"):
            point["external"][s] = None
        else:
            point["internal"][s] = fnum(r.get(s))

    return JsonResponse({"device_id": device_id, "offset": offset, "point": point})



# UI pages
def dashboard_view(request):
    return render(request, 'api/dashboard.html')

def signals_view(request):
    return render(request, 'api/signals.html')



def device_view(request):
    return render(request, 'api/device.html')


# -------------------------
# Page: Events
# -------------------------
def events_view(request):
    return render(request, 'api/events.html')

def reports_view(request):
    return render(request, "api/reports.html")

# --- Reports API (SAFE): build long history from CSV cache (no window limit, no stream dependency) ---
def reports_history_view(request):
    """/reports/history?device_id=agv18&limit=3600
    Returns:
      { ok, device_id, count, items:[{sort_key,y_pred,cls,overlay_url}], keys:[...] }
    Data source:
      _cache["by_device"][device_id] built by _load_csv_cached()
    """
    device_id = request.GET.get("device_id")
    if not device_id:
        return JsonResponse({"ok": False, "error": "device_id is required"}, status=400)

    try:
        limit = int(request.GET.get("limit", "3600"))
    except ValueError:
        limit = 3600
    limit = max(10, min(limit, 20000))

    _load_csv_cached()
    by_device = _cache.get("by_device") or {}
    rows = by_device.get(device_id)

    if not rows:
        return JsonResponse({"ok": False, "error": "device_id not found in cache", "device_id": device_id}, status=404)

    # rows are expected in time order already (as used by stream_tick)
    import re as _re
    def _sort_key_from_overlay(url):
        m = _re.search(r"_(\d{4}_\d{6})_", str(url or ""))
        return m.group(1) if m else None

    items = []
    keys = []

    # take last limit points
    for r in rows[-limit:]:
        # row r could be dict-like depending on loader; use .get
        overlay_url = r.get("overlay_url") if hasattr(r, "get") else None
        sort_key = _sort_key_from_overlay(overlay_url)

        y_pred = r.get("y_pred") if hasattr(r, "get") else None
                # cls priority: y_pred_cls -> cls -> fallback by y_pred threshold
        cls = None
        if hasattr(r, "get"):
            if r.get("y_pred_cls") is not None:
                try:
                    cls = int(r.get("y_pred_cls"))
                except Exception:
                    cls = None
            if cls is None and r.get("cls") is not None:
                try:
                    cls = int(r.get("cls"))
                except Exception:
                    cls = None

        # fallback: derive cls from y_pred (tune thresholds later)
        if cls is None:
            try:
                yp = float(y_pred)
                # 임시 기준(조정 가능): 0=정상,1=관심,2=경고,3=위험
                if yp < 0.8:
                    cls = 0
                elif yp < 1.6:
                    cls = 1
                elif yp < 2.4:
                    cls = 2
                else:
                    cls = 3
            except Exception:
                cls = 0

        items.append({
            "sort_key": sort_key,
            "y_pred": y_pred,
            "cls": cls,
            "overlay_url": overlay_url,
        })
        if sort_key and (len(keys) == 0 or keys[-1] != sort_key):
            keys.append(sort_key)

    return JsonResponse({
        "ok": True,
        "device_id": device_id,
        "count": len(items),
        "items": items,
        "keys": keys
    })





















