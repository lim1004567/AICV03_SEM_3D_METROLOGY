﻿from django.urls import path
from . import views

urlpatterns = [
        
    

    path("pred/history", views.pred_history),
    path("labels/history", views.labels_history),
    path("labels/now", views.labels_now),
    path("reports/history", views.reports_history_view, name="reports_history"),
path("reports/", views.reports_view, name="reports"),path("device/", views.device_view, name="device"),
path("", views.dashboard_view, name="dashboard"),
    path("signals/", views.signals_view, name="signals"),
    path("health", views.health),
    path("kpi", views.kpi),
    path("devices", views.devices),
    path("device/<str:device_id>/moments", views.device_moments),        path("events/", views.events_view, name="events_view"),

    path("events", views.events),

    # stream
    path("stream/reset", views.stream_reset_mtt_future),
    path("stream/tick", views.stream_tick_mtt_futurealert),
    path("signals/available", views.signals_available),
    path("signals/series", views.signals_series),
    path("signals/inspect", views.signals_inspect),
]
















