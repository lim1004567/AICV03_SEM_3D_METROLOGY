﻿import os
import csv
import time
from pathlib import Path
from datetime import datetime

from django.conf import settings
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import render


# ---------------------------
# CSV paths
# ---------------------------
# Pred CSV (model outputs)
BASE_CSV_PATH = Path(settings.BASE_DIR) / "final_17_18_with_overlay_and_pred.csv"

# Labels CSV (ground-truth now)
LABELS_CSV_PATH = Path(r"C:\Users\user\Downloads\CV(이송장치)\labels_17_18_sorted.csv")

# Signals tab uses labels CSV (keep as-is)
SIGNALS_CSV_PATH = LABELS_CSV_PATH


# ---------------------------
# caches
# ---------------------------
_base_cache = {"mtime": None, "by_device": None, "devices_latest": None}
_labels_cache = {"mtime": None, "by_device": None, "devices_latest": None}   # ground-truth cache
_signals_cache = {"mtime": None, "by_device": None, "devices_latest": None}  # signals cache (same file)

_stream = {
    "inited": False,
    "pos": {},        # device_id -> cursor index (next position to read)
    "hist": {},       # device_id -> list[point] (rolling window)
    "events": [],     # list of events (newest first)
    "last_cls": {},   # device_id -> previous "now" cls (ground-truth) for event generation
    "last_tick_at": None,
    "window": 30,
    "only_up": 1,
    "events_window": 600,
}


# ---------------------------
# helpers
# ---------------------------
def _now_iso():
    return datetime.now().isoformat(timespec="seconds")

def _safe_int(x, default=-1):
    try:
        s = str(x).strip()
        return int(s) if s.lstrip("-").isdigit() else default
    except Exception:
        return default

def _safe_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default

def _with_overlay_url(row: dict) -> dict:
    op = (row.get("overlay_path") or "").strip()
    if op:
        row["overlay_url"] = settings.STATIC_URL + os.path.basename(op)
    else:
        row["overlay_url"] = None
    return row

def _load_csv_to_cache(path: Path, cache: dict, add_overlay=False):
    if not path.exists():
        cache["mtime"] = None
        cache["by_device"] = {}
        cache["devices_latest"] = {}
        return

    mtime = path.stat().st_mtime
    if cache["by_device"] is not None and cache["mtime"] == mtime:
        return

    by_device = {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        for r in rd:
            if not isinstance(r, dict):
                continue
            did = (r.get("device_id") or "").strip()
            if not did:
                continue
            if add_overlay:
                r = _with_overlay_url(r)
            by_device.setdefault(did, []).append(r)

    devices_latest = {}
    for did, arr in by_device.items():
        arr_sorted = sorted(arr, key=lambda x: (x.get("sort_key") or ""))
        by_device[did] = arr_sorted
        devices_latest[did] = arr_sorted[-1] if arr_sorted else None

    cache["mtime"] = mtime
    cache["by_device"] = by_device
    cache["devices_latest"] = devices_latest

def _load_base_cached():
    _load_csv_to_cache(BASE_CSV_PATH, _base_cache, add_overlay=True)

def _load_labels_cached():
    _load_csv_to_cache(LABELS_CSV_PATH, _labels_cache, add_overlay=False)

def _load_signals_cached():
    _load_csv_to_cache(SIGNALS_CSV_PATH, _signals_cache, add_overlay=False)


# ---------------------------
# stream core (CSV cursor based)
# ---------------------------
def _stream_init(window=30, only_up=1, events_window=600):
    """
    Initialize stream cursor at 0 for each device.
    Uses:
      - labels CSV for now(y_true)
      - base CSV for pred(y_pred_cls, y_pred, overlay)
    """
    _load_base_cached()
    _load_labels_cached()

    base_by = _base_cache.get("by_device") or {}
    lab_by = _labels_cache.get("by_device") or {}

    # Use intersection of devices that exist in both CSVs
    devs = sorted(set(base_by.keys()) & set(lab_by.keys()))

    _stream["pos"] = {did: 0 for did in devs}
    _stream["hist"] = {did: [] for did in devs}
    _stream["events"] = []
    _stream["last_cls"] = {}
    _stream["last_tick_at"] = None
    _stream["window"] = int(window)
    _stream["only_up"] = 1 if str(only_up) in ("1", "true", "True") else 0
    _stream["events_window"] = int(events_window)
    _stream["inited"] = True

def _push_event(evt: dict):
    _stream["events"].insert(0, evt)
    if len(_stream["events"]) > 5000:
        del _stream["events"][5000:]

def _stream_end_index(device_id: str):
    """
    Current index already emitted (pos-1).
    """
    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)
    pos = _stream.get("pos", {}).get(device_id, 0)
    return max(0, pos - 1)

def _get_row_at(arr, idx):
    if not arr:
        return None
    if idx < 0:
        idx = 0
    if idx >= len(arr):
        return arr[-1]
    return arr[idx]

def _tick_once(window=30, only_up=1, events_window=600):
    """
    Advance cursor by 1 step per device and append a point into rolling history (max window).
    """
    if not _stream.get("inited"):
        _stream_init(window=window, only_up=only_up, events_window=events_window)

    # update parameters (allow runtime changes)
    _stream["window"] = int(window)
    _stream["only_up"] = 1 if str(only_up) in ("1", "true", "True") else 0
    _stream["events_window"] = int(events_window)

    _load_base_cached()
    _load_labels_cached()

    base_by = _base_cache.get("by_device") or {}
    lab_by = _labels_cache.get("by_device") or {}

    now = time.time()
    _stream["last_tick_at"] = now

    current = {}

    for did in list(_stream.get("pos", {}).keys()):
        base_arr = base_by.get(did, [])
        lab_arr = lab_by.get(did, [])
        if not base_arr or not lab_arr:
            continue

        pos = _stream["pos"].get(did, 0)

        # Use same cursor position for both (assumes same sort_key alignment order)
        r_pred = _get_row_at(base_arr, pos)
        r_now  = _get_row_at(lab_arr, pos)

        # advance cursor (next time)
        _stream["pos"][did] = pos + 1

        now_cls = _safe_int(r_now.get("y_true"), default=-1)
        prev_cls = _stream["last_cls"].get(did)

        # event on NOW cls changes (ground-truth)
        if prev_cls is not None and now_cls != prev_cls:
            up = (now_cls > prev_cls)
            if (_stream["only_up"] == 0) or up:
                _push_event({
                    "device_id": did,
                    "from_cls": prev_cls,
                    "to_cls": now_cls,
                    "y_pred": _safe_float(r_pred.get("y_pred"), 0.0),
                    "overlay_url": r_pred.get("overlay_url"),
                    "t": int(now),
                })

        _stream["last_cls"][did] = now_cls

        pred_cls = _safe_int(r_pred.get("y_pred_cls"), default=-1)
        pred_y   = _safe_float(r_pred.get("y_pred"), 0.0)

        pt = {
            # current (NOW) from labels CSV
            "cls": now_cls,
            "sort_key": r_now.get("sort_key") or r_pred.get("sort_key"),
            # predicted (FUTURE) from pred CSV (same time index)
            "pred_cls": pred_cls,
            "pred_y_pred": pred_y,

            # keep score/overlay fields for UI usage
            "y_pred": pred_y,
            "overlay_url": r_pred.get("overlay_url"),
        }

        hist = _stream["hist"].setdefault(did, [])
        hist.append(pt)

        # keep only last window points
        w = int(_stream["window"])
        if len(hist) > w:
            del hist[:-w]

        current[did] = pt

    # apply events_window
    cutoff = int(now) - int(_stream.get("events_window", 600))
    _stream["events"] = [e for e in (_stream.get("events") or []) if e.get("t", 0) >= cutoff]

    return current


# ---------------------------
# STREAM endpoint (existing route uses this)
# ---------------------------
def stream_tick(request):
    """
    1Hz-like streaming tick (cursor-based).
    - NOW from labels CSV (y_true)
    - PRED from pred CSV (y_pred_cls / y_pred)
    """
    try:
        window = int(request.GET.get("window", "30"))
    except ValueError:
        window = 30
    window = max(5, min(window, 300))

    try:
        events_window = int(request.GET.get("events_window", "600"))
    except ValueError:
        events_window = 600
    events_window = max(60, min(events_window, 3600))

    only_up = request.GET.get("only_up", "1")
    only_up = 1 if str(only_up) in ("1", "true", "True") else 0

    current = _tick_once(window=window, only_up=only_up, events_window=events_window)

    total = len(current)
    danger = sum(1 for v in current.values() if v.get("cls") == 3)
    warn = sum(1 for v in current.values() if v.get("cls") == 2)

    top_risk = None
    if current:
        did2, v2 = max(current.items(), key=lambda kv: kv[1].get("pred_y_pred", 0.0))
        top_risk = {"device_id": did2, "score": v2.get("pred_y_pred", 0.0), "state": v2.get("cls", -1)}

    latest_alert = None
    cand = [(did3, v3) for did3, v3 in current.items() if v3.get("cls") in (2, 3)]
    if cand:
        cand.sort(key=lambda kv: (kv[1].get("cls", -1), kv[1].get("pred_y_pred", 0.0)), reverse=True)
        did3, v3 = cand[0]
        latest_alert = {
            "device_id": did3,
            "state": v3.get("cls"),
            "score": v3.get("pred_y_pred"),
            "overlay_url": v3.get("overlay_url"),
        }

    types = {"oht": 0, "agv": 0}
    for did in current.keys():
        if str(did).lower().startswith("oht"):
            types["oht"] += 1
        elif str(did).lower().startswith("agv"):
            types["agv"] += 1

    return JsonResponse({
        "ok": True,
        "server_time": _now_iso(),
        "active_devices": total,
        "device_types": types,
        "danger_now": danger,
        "warning_now": warn,
        "recent_events": len(_stream.get("events") or []),
        "top_risk": top_risk,
        "latest_alert": latest_alert,
        "only_up": only_up,
        "events_window": events_window,
        "window": window,
        "current": current,
        "history": _stream.get("hist") or {},
        "events": (_stream.get("events") or [])[:10],
    })


# ---------------------------
# SIGNALS APIs (Signals tab)
# ---------------------------
def _sig_to_col(s: str) -> str:
    s = (s or "").strip()
    return s[4:] if s.startswith("s29_") else s

def _col_to_sig(c: str) -> str:
    c = (c or "").strip()
    return c if c.startswith("s29_") else ("s29_" + c)

def _get_fieldnames():
    _load_signals_cached()
    by_device = _signals_cache.get("by_device") or {}
    for _, arr in by_device.items():
        if arr:
            return list(arr[0].keys())
    return []

def _default_presets(fieldnames):
    raw = set(fieldnames)
    dust_raw = [x for x in ["PM10", "PM2_5", "PM1_0"] if x in raw]
    thermal_raw = [x for x in ["CT1", "CT2", "CT3", "CT4", "NTC"] if x in raw]
    internal_raw = [x for x in ["NTC","PM10","PM2_5","PM1_0","CT1","CT2","CT3","CT4"] if x in raw]
    return {
        "Dust": [_col_to_sig(x) for x in dust_raw],
        "Thermal": [_col_to_sig(x) for x in thermal_raw],
        "Internal": [_col_to_sig(x) for x in internal_raw],
        "External": []
    }

def signals_available(request):
    fieldnames = _get_fieldnames()
    meta = set(["device_id","device_type","device_num","sort_key","bin_path","y_true","overlay_url","overlay_path"])
    raw_cols = [c for c in fieldnames if c not in meta]
    signals = [_col_to_sig(c) for c in raw_cols]
    presets = _default_presets(fieldnames)
    return JsonResponse({
        "device_hint": request.GET.get("device_id"),
        "presets": presets,
        "signals": signals,
        "external_mock": ["ex_temperature","ex_humidity","ex_illuminance"],
    })

def _current_sort_key_from_stream(device_id: str):
    """
    stream cursor 기준 sort_key를 가져옴 (labels cache 기준).
    """
    try:
        if not _stream.get("inited"):
            _stream_init(window=30, only_up=1, events_window=600)
        _load_labels_cached()
        arr = (_labels_cache.get("by_device") or {}).get(device_id, [])
        if not arr:
            return None
        end = _stream_end_index(device_id)
        end = max(0, min(end, len(arr) - 1))
        return arr[end].get("sort_key")
    except Exception:
        return None

def _find_index_by_sort_key(arr, sort_key: str):
    if not arr or not sort_key:
        return None
    for i in range(len(arr)-1, -1, -1):
        if (arr[i].get("sort_key") or "") == sort_key:
            return i
    return None

def _slice_rows_by_cursor(device_id: str, limit: int):
    _load_signals_cached()
    arr = (_signals_cache.get("by_device") or {}).get(device_id, [])
    if not arr:
        return []

    sk = _current_sort_key_from_stream(device_id)
    idx = _find_index_by_sort_key(arr, sk) if sk else None
    end = idx if idx is not None else (len(arr) - 1)

    start = max(0, end - (limit - 1))
    return arr[start:end+1]

def signals_series(request):
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    sigs = (request.GET.get("signals") or "").strip()
    if not sigs:
        return HttpResponseBadRequest("signals required (comma-separated)")
    signals = [_sig_to_col(s.strip()) for s in sigs.split(",") if s.strip()]

    try:
        limit = int(request.GET.get("limit", "60"))
    except ValueError:
        limit = 60
    limit = max(3, min(limit, 200000))

    from_start = request.GET.get("from_start", "0")
    from_start = 1 if str(from_start) in ("1", "true", "True") else 0

    if from_start:
        _load_labels_cached()
        arr = (_labels_cache.get("by_device") or {}).get(device_id, [])
        end = _stream_end_index(device_id)
        rows = arr[max(0, end-(limit-1)) : end+1]
    else:
        rows = _slice_rows_by_cursor(device_id, limit=limit)

    def fnum(x):
        try:
            return float(x)
        except Exception:
            return None

    mode = (request.GET.get("mode") or "").strip().lower()

    if mode == "keys":
        keys = []
        last = None
        for rr in rows:
            k = rr.get("sort_key")
            if not k:
                continue
            if k != last:
                keys.append(k)
                last = k
        return JsonResponse({"device_id": device_id, "keys": keys, "count": len(keys), "limit": limit})

    points = []
    for r in rows:
        st = fnum(r.get("y_true"))
        sc = None
        p = {"t": r.get("sort_key"), "state": st, "score": sc}
        for s in signals:
            if s.startswith("ex_"):
                p[s] = None
            else:
                p[_col_to_sig(s)] = fnum(r.get(s))
        points.append(p)

    return JsonResponse({
        "device_id": device_id,
        "signals": [_col_to_sig(s) for s in signals],
        "points": points,
        "limit": limit
    })

def signals_inspect(request):
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    sigs = (request.GET.get("signals") or "").strip()
    signals = [_sig_to_col(s.strip()) for s in sigs.split(",") if s.strip()] if sigs else []

    try:
        offset = int(request.GET.get("offset", "0"))
    except ValueError:
        offset = 0
    offset = max(0, min(offset, 600))

    _load_signals_cached()
    arr = (_signals_cache.get("by_device") or {}).get(device_id, [])
    if not arr:
        return JsonResponse({"device_id": device_id, "point": None})

    sk = _current_sort_key_from_stream(device_id)
    base_idx = _find_index_by_sort_key(arr, sk) if sk else None
    end = base_idx if base_idx is not None else (len(arr) - 1)
    idx = max(0, end - offset)
    r = arr[idx]

    def fnum(x):
        try:
            return float(x)
        except Exception:
            return None

    point = {
        "t": r.get("sort_key"),
        "state": fnum(r.get("y_true")),
        "score": None,
        "overlay_url": None,
        "internal": {},
        "external": {"ex_temperature": None, "ex_humidity": None, "ex_illuminance": None},
    }

    for s in signals:
        if s.startswith("ex_"):
            point["external"][s] = None
        else:
            point["internal"][_col_to_sig(s)] = fnum(r.get(s))

    return JsonResponse({"device_id": device_id, "offset": offset, "point": point})


# ---------------------------
# UI pages
# ---------------------------
def dashboard_view(request):
    return render(request, "api/dashboard.html")

def device_view(request):
    return render(request, "api/device.html")

def signals_view(request):
    return render(request, "api/signals.html")

def events_view(request):
    return render(request, "api/events.html")

def reports_view(request):
    return render(request, "api/reports.html")


# ---------------------------
# Labels NOW / HISTORY (ground-truth via stream cursor)
# ---------------------------
def labels_now(request):
    """
    NOW (ground-truth) per device using stream cursor.
    Returns: { ok, server_time, items:[{device_id, cls, sort_key}] }
    """
    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    _load_labels_cached()
    lab_by = _labels_cache.get("by_device") or {}

    out = []
    for did in sorted(_stream.get("pos", {}).keys()):
        arr = lab_by.get(did, [])
        if not arr:
            continue
        end = _stream_end_index(did)
        r = _get_row_at(arr, end)
        if not r:
            continue
        cls = _safe_int(r.get("y_true"), default=-1)
        out.append({
            "device_id": did,
            "cls": cls,
            "sort_key": r.get("sort_key"),
        })

    return JsonResponse({"ok": True, "server_time": _now_iso(), "items": out, "count": len(out)})

def labels_history(request):
    """
    Recent N ground-truth states for a device from stream history (rolling window).
    GET: device_id, limit (default 30)
    Returns: { ok, server_time, device_id, items:[{t, cls}] }
    """
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    try:
        limit = int(request.GET.get("limit", "30"))
    except ValueError:
        limit = 30
    limit = max(1, min(limit, 300))

    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    hist = (_stream.get("hist") or {}).get(device_id, [])
    tail = hist[-limit:] if hist else []

    items = []
    for pt in tail:
        items.append({"t": pt.get("sort_key"), "cls": _safe_int(pt.get("cls"), default=-1)})

    return JsonResponse({"ok": True, "server_time": _now_iso(), "device_id": device_id, "items": items, "count": len(items), "limit": limit})


# ---------------------------
# Reports history (placeholder kept)
# ---------------------------
def reports_history_view(request):
    device_id = request.GET.get("device_id")
    if not device_id:
        return JsonResponse({"ok": False, "error": "device_id is required"}, status=400)
    return JsonResponse({"ok": True, "device_id": device_id, "items": [], "count": 0})


# ---------------------------
# Pred history (from stream history)
# ---------------------------
def pred_history(request):
    """
    Recent N predicted states for a device from stream history (rolling window).
    GET: device_id, limit (default 30)
    Returns: { ok, server_time, device_id, items:[{t, cls}] }
    """
    device_id = (request.GET.get("device_id") or "").strip()
    if not device_id:
        return HttpResponseBadRequest("device_id required")

    try:
        limit = int(request.GET.get("limit", "30"))
    except ValueError:
        limit = 30
    limit = max(1, min(limit, 300))

    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    hist = (_stream.get("hist") or {}).get(device_id, [])
    tail = hist[-limit:] if hist else []

    items = []
    for pt in tail:
        items.append({"t": pt.get("sort_key"), "cls": _safe_int(pt.get("pred_cls"), default=-1)})

    return JsonResponse({"ok": True, "server_time": _now_iso(), "device_id": device_id, "items": items, "count": len(items), "limit": limit})


# ---------------------------
# Health
# ---------------------------
def health(request):
    return JsonResponse({"ok": True, "server_time": _now_iso()})


# ---------------------------
# endpoints required by api/urls.py
# ---------------------------
def kpi(request):
    """
    KPI based on NOW (ground-truth) from stream cursor.
    """
    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    # Ensure at least one tick has happened when dashboard starts pulling:
    # KPI should still work even before first tick -> use end_index(0)
    _load_labels_cached()
    lab_by = _labels_cache.get("by_device") or {}

    cur = {}
    for did in sorted(_stream.get("pos", {}).keys()):
        arr = lab_by.get(did, [])
        if not arr:
            continue
        end = _stream_end_index(did)
        r = _get_row_at(arr, end)
        if not r:
            continue
        cls = _safe_int(r.get("y_true"), default=-1)
        cur[did] = {"cls": cls}

    total = len(cur)
    danger = sum(1 for v in cur.values() if v.get("cls") == 3)
    warn = sum(1 for v in cur.values() if v.get("cls") == 2)

    return JsonResponse({
        "ok": True,
        "server_time": _now_iso(),
        "active_devices": total,
        "danger_now": danger,
        "warning_now": warn,
    })

def devices(request):
    """
    Device cards / prediction payload for dashboard.
    Uses stream cursor (pred from pred CSV, now cls is provided by /labels/now).
    """
    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    _load_base_cached()
    base_by = _base_cache.get("by_device") or {}

    out = []
    for did in sorted(_stream.get("pos", {}).keys()):
        arr = base_by.get(did, [])
        if not arr:
            continue
        end = _stream_end_index(did)
        r = _get_row_at(arr, end)
        if not r:
            continue

        pred_cls = _safe_int(r.get("y_pred_cls"), default=-1)
        pred_y = _safe_float(r.get("y_pred"), 0.0)

        out.append({
            "device_id": did,
            "device_type": (r.get("device_type") or ""),
            # keep cls as pred_cls for compatibility
            "cls": pred_cls,
            "y_pred": pred_y,
            "pred_cls": pred_cls,
            "pred_y_pred": pred_y,
            "sort_key": r.get("sort_key"),
            "overlay_url": r.get("overlay_url"),
        })

    return JsonResponse({"ok": True, "items": out, "count": len(out)})

def device_moments(request, device_id: str):
    """
    Moments from pred CSV around current cursor.
    """
    try:
        limit = int(request.GET.get("limit", "60"))
    except ValueError:
        limit = 60
    limit = max(5, min(limit, 5000))

    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    _load_base_cached()
    arr = (_base_cache.get("by_device") or {}).get(device_id, [])
    if not arr:
        return JsonResponse({"ok": True, "device_id": device_id, "items": [], "count": 0})

    end = _stream_end_index(device_id)
    start = max(0, end - (limit - 1))
    rows = arr[start:end+1]

    items = []
    for r in rows:
        items.append({
            "t": r.get("sort_key"),
            "cls": _safe_int(r.get("y_pred_cls"), default=-1),
            "y_pred": _safe_float(r.get("y_pred"), 0.0),
            "overlay_url": r.get("overlay_url"),
        })

    return JsonResponse({"ok": True, "device_id": device_id, "items": items, "count": len(items), "end": end})

def events(request):
    """
    Events generated from NOW(ground-truth) cls changes.
    """
    try:
        limit = int(request.GET.get("limit", "50"))
    except ValueError:
        limit = 50
    limit = max(1, min(limit, 500))

    if not _stream.get("inited"):
        _stream_init(window=30, only_up=1, events_window=600)

    ev = _stream.get("events") or []
    return JsonResponse({"ok": True, "items": ev[:limit], "count": len(ev)})

def stream_reset(request):
    try:
        window = int(request.GET.get("window", "30"))
    except ValueError:
        window = 30
    window = max(5, min(window, 300))

    only_up = request.GET.get("only_up", "1")
    only_up = 1 if str(only_up) in ("1", "true", "True") else 0

    try:
        events_window = int(request.GET.get("events_window", "600"))
    except ValueError:
        events_window = 600
    events_window = max(60, min(events_window, 3600))

    _stream_init(window=window, only_up=only_up, events_window=events_window)
    return JsonResponse({"ok": True, "reset": True, "window": window, "only_up": only_up, "events_window": events_window, "server_time": _now_iso()})


# ---------------------------
# Compatibility aliases (api/urls.py expects these)
# ---------------------------
def stream_reset_mtt_future(request):
    return stream_reset(request)

def stream_tick_mtt_futurealert(request):
    return stream_tick(request)

def stream_tick_mtt_futurealert_overlay(request):
    return stream_tick(request)