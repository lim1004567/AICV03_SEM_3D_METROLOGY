﻿import os, time, json
import pandas as pd

ROOT = r"C:\Users\user\Downloads\CV(이송장치)"
LSTM_CSV = os.path.join(ROOT, "test_17_18_with_pred_LSTM.csv")
MMT_CSV  = os.path.join(ROOT, "final_17_18_with_overlay_and_pred.csv")
OUT_JSON = os.path.join(ROOT, "latest_merged.json")

def state_name(s:int)->str:
    s = int(s)
    if s < 0: s = 0
    if s > 3: s = 3
    return ["Normal (0)","Attention (1)","Warning (2)","Danger (3)"][s]

def sk_to_int(sk:str)->int:
    # "MMDD_HHMMSS" -> int for sorting
    try:
        md, t = str(sk).split("_")
        return int(md)*1000000 + int(t)
    except:
        return -1

def build_table(df:pd.DataFrame, id_col="device_id"):
    df = df.copy()
    df["_sk"] = df["sort_key"].astype(str).map(sk_to_int)
    df = df.sort_values([id_col, "_sk"]).reset_index(drop=True)
    groups = {}
    for did, g in df.groupby(id_col, sort=False):
        groups[str(did).lower()] = g.reset_index(drop=True)
    return groups

print("loading CSVs...")
lstm_df = pd.read_csv(LSTM_CSV)
mmt_df  = pd.read_csv(MMT_CSV)

for need in ["device_id","sort_key","y_pred","y_pred_cls"]:
    if need not in lstm_df.columns: raise SystemExit(f"[LSTM] missing col: {need}")
    if need not in mmt_df.columns:  raise SystemExit(f"[MMT] missing col: {need}")

lstm_g = build_table(lstm_df)
mmt_g  = build_table(mmt_df)

devs = [d for d in ["agv17","agv18","oht17","oht18"] if d in lstm_g and d in mmt_g]
if not devs:
    devs = sorted(set(lstm_g.keys()) & set(mmt_g.keys()))
print("devices:", devs)

idx = {d:0 for d in devs}

print("replaying... (Ctrl+C to stop)")
while True:
    out_devices = []

    for d in devs:
        g1 = lstm_g[d]
        g2 = mmt_g[d]
        i  = idx[d]

        if i >= len(g1): i = len(g1)-1
        if i >= len(g2): i = len(g2)-1
        if i < 0: i = 0

        r1 = g1.iloc[i]
        r2 = g2.iloc[i]

        cur_score = float(r1["y_pred"])
        cur_state = int(r1["y_pred_cls"])
        pred_score= float(r2["y_pred"])
        pred_state= int(r2["y_pred_cls"])

        out_devices.append({
            "device_id": d,
            "sort_key": str(r2["sort_key"]),  # pred 기준 sort_key
            "current": {
                "score": cur_score,
                "state": cur_state,
                "state_name": state_name(cur_state)
            },
            "pred": {
                "score": pred_score,
                "state": pred_state,
                "state_name": state_name(pred_state)
            }
        })

        idx[d] = idx[d] + 1  # 1초마다 한 칸 진행

    payload = {
        "server_time": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "devices": out_devices
    }

    tmp = OUT_JSON + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, OUT_JSON)  # atomic replace on Windows

    time.sleep(1)
